package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod {
	//click leads link
	/*
	 * public MyLeadsPage clickLeadsLink() {
	 * driver.findElementByLinkText("Leads").click(); return new MyLeadsPage(); }
	 */

	/*
	 * public MyLeadsPage clickLeadsLink() {
	 * driver.findElementByLinkText("Leads").click(); return new MyLeadsPage(); }
	 */

	public MyHomePage(ChromeDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
		
	}

	public MyLeadsPage clickLeadsLink() {
		driver.findElementByLinkText(prop.getProperty("myhomepage.leads.linktext")).click();
		return new MyLeadsPage(driver);
	}

}

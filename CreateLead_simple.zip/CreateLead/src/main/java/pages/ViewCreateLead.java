package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewCreateLead extends ProjectSpecificMethod {
	public ViewCreateLead(ChromeDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}

	//verification
	public ViewCreateLead verificationofCreateLead()
	{
		System.out.println("verification of create lead");
		return this;
	}

}

package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyLeadsPage extends ProjectSpecificMethod{
	public MyLeadsPage(ChromeDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}

	//click Create lead
	public CreateLeadPage clickCreateLead()
	{
		driver.findElementByLinkText(prop.getProperty("myleadspage.createlead.linktext")).click();
		return new CreateLeadPage(driver);
	}

}

package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod {

	//click crmsfa link
	/*
	 * public MyHomePage clickCrmsfalink() {
	 * driver.findElementByLinkText("CRM/SFA").click(); return new MyHomePage(); }
	 */

	public HomePage(ChromeDriver driver) {
		this.driver=driver;
	}

	public MyHomePage clickCrmsfalink() {
		// TODO Auto-generated method stub
		driver.findElementByLinkText(prop.getProperty("homepage.crmsfalink.linktext")).click(); 
		return new MyHomePage(driver);
		
	}
	
}

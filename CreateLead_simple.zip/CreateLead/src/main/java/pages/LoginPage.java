package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{
 
	
	public LoginPage(ChromeDriver driver) {
		this.driver=driver;
		
	}
	//enter username
	
	  public LoginPage enterUsername() {
	  driver.findElementById(prop.getProperty("login.username.id")).sendKeys("Demosalesmanager");
	  return this;
	  
	  }
	 
	//enter password
	public LoginPage enterPassword()
	{
		
		driver.findElementById(prop.getProperty("login.password.id")).sendKeys("crmsfa");
		return this;
	}
	//click login button
	public HomePage clickLoginButton()
	{
		driver.findElementByClassName(prop.getProperty("login.login.class")).click();
		
        return new HomePage(driver);
	}
	/*
	 * public LoginPage enterUsername() {
	 * 
	 * driver.findElementById("username").sendKeys("Demosalesmanager"); return this;
	 * }
	 */
	
}

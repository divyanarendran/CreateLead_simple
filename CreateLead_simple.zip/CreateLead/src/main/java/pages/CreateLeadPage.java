package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{
	public CreateLeadPage(ChromeDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	//enter firstName
	public CreateLeadPage enterFirstName()
	{
		driver.findElementById(prop.getProperty("createlead.firstname.id")).sendKeys("Hari");
		return this;
	}
	//enter lastname
	public CreateLeadPage enterLastName()
	{
		driver.findElementById(prop.getProperty("createlead.lastname.id")).sendKeys("Prasad");
		return this;
	}
	//enter company name
	public CreateLeadPage enterCompanyName()
	{

		driver.findElementById(prop.getProperty("createlead.companyname.id")).sendKeys("TestLeaf");
		return this;
	}
	//click submit button
	public ViewCreateLead clickSubmitButton()
	{
		driver.findElementByName(prop.getProperty("createlead.submitbutton.name")).click();
		return new ViewCreateLead(driver);
		
	}

	
}

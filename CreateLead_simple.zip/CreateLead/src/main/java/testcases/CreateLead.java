package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethod{
	@Test
	public void runCreateLead()
	{
		LoginPage lp =new LoginPage(driver);
		lp.enterUsername()
	      .enterPassword()
          .clickLoginButton()
		.clickCrmsfalink()
		.clickLeadsLink()
		.clickCreateLead()
		.enterFirstName()
		.enterLastName()
		.enterCompanyName()
		.clickSubmitButton()
		.verificationofCreateLead();
	}

}

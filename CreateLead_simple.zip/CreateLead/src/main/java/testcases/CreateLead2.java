package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateLead2 extends ProjectSpecificMethod{
@Test


public void runCreateLead2()
{
	LoginPage lp =new LoginPage(driver);
	lp.enterUsername()
      .enterPassword()
      .clickLoginButton()
	.clickCrmsfalink()
	.clickLeadsLink()
	.clickCreateLead()
	.enterFirstName()
	.enterLastName()
	.enterCompanyName()
	.clickSubmitButton()
	.verificationofCreateLead();
}
}

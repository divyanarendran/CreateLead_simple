package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

public class ProjectSpecificMethod {
public ChromeDriver driver;
public static Properties prop;
@BeforeSuite
public void loadProperties() throws FileNotFoundException, IOException
{
	prop=new Properties();
	
	prop.load(new FileInputStream("./src/main/resources/english.properties"));
	}
@BeforeMethod
public void startApp()
{
System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
driver = new ChromeDriver();	 
driver.manage().window().maximize();
driver.get("http://leaftaps.com/opentaps/control/main");
}

@AfterMethod
public void closeBrowser()
{
	driver.close();
}


}
